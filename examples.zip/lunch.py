'''Fancier format string example.'''

part1 = 'lunch'
part2 = 'box'
format = 'The words %s and %s can appear separately or together: %s%s.'
print  format % (part1, part2, part1, part2)
