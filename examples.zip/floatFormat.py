'''Test float formatting with %._f.'''

x = 2.876543
print 'longer: %.5f, shorter: %.3f' % (x, x)
