'''Test yourself with this variation.  What happens?'''

i = 4
while (i < 9):
    i = i+2
    print i
