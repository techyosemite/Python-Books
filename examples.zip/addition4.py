'''Two numeric inputs in one input statement'''

x, y = input("Enter two comma separated numbers: ")
print 'The sum of %s and %s is %s.' % (x, y, x+y)
