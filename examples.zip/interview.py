'''Illustrate raw_input and print.'''

applicant = raw_input("Enter the applicant's name: ")
interviewer = raw_input("Enter the interviewer's name: ")
time = raw_input("Enter the appointment time: ")
print interviewer, "will interview", applicant, "at", time
