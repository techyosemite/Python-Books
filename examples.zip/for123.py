'''Python program files do not require a blank line after a loop.
They only require the next line to be dedented.
'''

for count in [1, 2, 3]:
    print count
    print 'Yes' * count
print 'Done countng.'
for color in ['red', 'blue', 'green']:
    print color
