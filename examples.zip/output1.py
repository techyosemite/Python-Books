output = file('sample.txt', 'w')
output.write('My first output file!')
output.close()
