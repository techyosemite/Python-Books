'''A simple while loop.'''

temperature = 115
while temperature > 112:
    print temperature
    temperature = temperature - 1

print 'The tea is cool enough.'
