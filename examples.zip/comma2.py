def listOnOneLine(items):
    for item in items:
        print item,
    print

listOnOneLine(['apple', 'banana', 'pear'])
print 'This is probably better!'
