'''simple sequential code updating two variables.
'''
x = 3          #1
y = x + 2      #2
y = 2*y        #3
x = y - x      #4
print x, y     #5
