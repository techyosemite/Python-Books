'''Error in addition from raw_input.'''

x = raw_input("Enter a number: ")
y = raw_input("Enter a second number: ")
print 'The sum of %s and %s is %s.' % (x, y, x+y)
