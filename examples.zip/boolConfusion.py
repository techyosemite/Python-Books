'''Test condition ans=='y' or 'yes'.'''

ans = 'y'
if ans == 'y' or 'yes':
    print 'y is OK'

ans = 'no'
if ans == 'y' or 'yes':
    print 'no is OK!!???'
